package com.example.loginremembermesharedpreferences;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
EditText ed1,ed2;
CheckBox c1;
Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ed1 = findViewById(R.id.editTextTextPersonName);
        ed2 = findViewById(R.id.editTextTextPassword);

        c1 = findViewById(R.id.checkBox);

        b1 = findViewById(R.id.button);

        SharedPreferences preferences = getSharedPreferences("login_preferences", MODE_PRIVATE);

        String email = preferences.getString("email", "");
        String password = preferences.getString("password", "");

        if(!email.isEmpty() && !password.isEmpty()){
            if(email.equals("narender.rk10@gmail.com") && password.equals("Vesit@10"))
            {
                Intent i=new Intent(getApplicationContext(), WelcomeActivity.class);
                startActivity(i);
                finish();
                return;
            }
        }

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email1 = ed1.getText().toString();
                String password1 = ed2.getText().toString();

                if(c1.isChecked())
                {
                    boolean check = loginCheck(email1,password1);
                    if(check)
                    {
                        SharedPreferences.Editor myEdit = preferences.edit();
                        myEdit.putString("email", email1);
                        myEdit.putString("password", password1);
                        myEdit.putString("name", "Narender Keswani");
                        myEdit.commit();
                        Intent i = new Intent(getApplicationContext(), WelcomeActivity.class);
                        startActivity(i);
                        finish();
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(),"Invalid Creditionals", Toast.LENGTH_LONG).show();
                    }

                }
                else
                {
                    boolean check = loginCheck(email1,password1);
                    if(check)
                    {
                        Intent i = new Intent(getApplicationContext(), WelcomeActivity.class);
                        startActivity(i);
                        finish();
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(),"Invalid Creditionals", Toast.LENGTH_LONG).show();
                    }
                }

            }
        });


    }

    public boolean loginCheck(String email, String password)
    {
        if(email.equals("narender.rk10@gmail.com") && password.equals("Vesit@10"))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}