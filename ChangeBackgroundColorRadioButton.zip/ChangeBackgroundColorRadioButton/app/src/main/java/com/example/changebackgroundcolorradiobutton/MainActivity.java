package com.example.changebackgroundcolorradiobutton;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    RadioGroup radioGroup;
    RadioButton rb;
    Button b1;
    LinearLayout linearLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        linearLayout = findViewById(R.id.linearLayout);
        radioGroup=(RadioGroup)findViewById(R.id.radioGroup);

        b1 = findViewById(R.id.button);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int selectedId = radioGroup.getCheckedRadioButtonId();
                rb = (RadioButton) findViewById(selectedId);

                if(selectedId==-1){
                    Toast.makeText(MainActivity.this,"Nothing selected", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(MainActivity.this,rb.getText(), Toast.LENGTH_SHORT).show();
                    if(rb.getText().toString().equals("RED"))
                    {
                        linearLayout.setBackgroundColor(Color.RED);
                    }
                    if(rb.getText().toString().equals("YELLOW"))
                    {
                        linearLayout.setBackgroundColor(Color.YELLOW);
                    }
                    if(rb.getText().toString().equals("BLUE"))
                    {
                        linearLayout.setBackgroundColor(Color.BLUE);
                    }
                }
            }
        });



    }
}