package com.example.asynctaskexample;

import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.os.Bundle;

import java.io.InputStream;

public class MainActivity extends AppCompatActivity {
    Button btn_start;
    String url1 = "https://i.imgur.com/jeuhNQz.png";
    ImageView sourceImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn_start = (Button) findViewById(R.id.btn_start);

        sourceImageView = (ImageView) findViewById(R.id.sourceImageView);
        btn_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                new AsyncTaskExample().execute(url1);
            }
        });

    }
    private class AsyncTaskExample extends AsyncTask<String, String, Bitmap> {
        ProgressDialog progressDialog;

        protected Bitmap doInBackground(String... strings) {
            String urldisplay = strings[0];
            Bitmap bitmap = null;
            publishProgress(String.valueOf(0));
            try {
                InputStream in = new java.net.URL(urldisplay).openStream();
                bitmap = BitmapFactory.decodeStream(in);
            } catch (Exception e) {
                Log.e("Error", e.getMessage());
                e.printStackTrace();
            }
            return bitmap;
        }

        protected void onProgressUpdate(Integer... values) {

        }

        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            progressDialog.dismiss();

            if (bitmap != null) {
                sourceImageView.setImageBitmap(bitmap);
            }
        }


        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = ProgressDialog.show(MainActivity.this, "Downloading", "Downloading..Please Wait", true);

        }

    }
}
