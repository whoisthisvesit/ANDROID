package com.tymca.www.internalfile;
import java.io.*;
import android.util.*;

public class FileOperations {
    public FileOperations()
    {

    }
    public boolean write(String fname,String fcontent)
    {
        try
        {
            String fpath="/sdcard/"+fname+".txt";
            File file = new File(fpath);
            if(!file.exists())
            {
                file.createNewFile();
            }
            FileWriter fw = new FileWriter(file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(fcontent);
            bw.close();
            Log.d("Success","Sucess");
            return true;
        }catch(IOException e)
        {
            e.printStackTrace();
            return false;
        }
    }
    public String read(String fname)
    {
        BufferedReader br = null;
        String response =null;
        try
        {
            StringBuffer output = new StringBuffer();
            String fpath="/sdcard/"+fname+".txt";
            br = new BufferedReader(new FileReader(fpath));
            String line = "";
            while ((line = br.readLine())!=null)
            {
                output.append(line+"n");
            }
            response = output.toString();
        }catch(IOException e)
        {
            e.printStackTrace();
            return null;
        }
        return response;
    }
}
