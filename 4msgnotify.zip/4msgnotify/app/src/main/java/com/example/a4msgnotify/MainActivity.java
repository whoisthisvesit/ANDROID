package com.example.a4msgnotify;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.view.View.OnClickListener;
import android.widget.RadioGroup.OnCheckedChangeListener;

public class MainActivity extends Activity {
    private Button btnSubmitQuiz;
    int score, ans1, ans2;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RadioGroup b1 = (RadioGroup) findViewById(R.id.answer1);
        b1.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                // TODO Auto-generated method stub
                switch (checkedId) {
                    case R.id.answer1A:
                        ans1 = 1;
                        break;
                    case R.id.answer1B:
                        ans1 = 2;
                        break;
                    case R.id.answer1C:
                        ans1 = 3;
                        break;
                    case R.id.answer1D:
                        ans1 = 4;
                        break;
                }
            }
        });
        RadioGroup b2 = (RadioGroup) findViewById(R.id.answer2);
        b2.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                // TODO Auto-generated method stub
                switch (checkedId) {
                    case R.id.answer2A:
                        ans2 = 1;
                        break;
                    case R.id.answer2B:
                        ans2 = 2;

                        break;
                    case R.id.answer2C:
                        ans2 = 3;
                        break;
                    case R.id.answer2D:
                        ans2 = 4;
                        break;
                }
            }
        });
        btnSubmitQuiz = (Button) findViewById(R.id.submit);
        btnSubmitQuiz.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);
                alertDialog.setTitle("SHOW RESULT");
                alertDialog.setMessage("Are you sure you want SUBMIT this?");
                alertDialog.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        score = 0;
                        // TODO Auto-generated method stub
                        if (ans1 == 2)
                            score++;
                        if (ans2 == 3)
                            score++;
                        Toast.makeText(MainActivity.this, "Your score is:" + score + " out of 2.", Toast.LENGTH_LONG).show();

                    }
                });
                // Setting Negative "NO" Button
                alertDialog.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // Write your code here to invoke NO event
                        Toast.makeText(getApplicationContext(), "You clicked NO.CHECK YOUR ANSWER", Toast.LENGTH_SHORT).show();
                        dialog.cancel();
                    }
                });
                // Showing Alert Message
                alertDialog.show();
            }
        });

    }
}
