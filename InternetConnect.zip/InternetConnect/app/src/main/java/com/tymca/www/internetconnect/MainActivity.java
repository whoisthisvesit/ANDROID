package com.tymca.www.internetconnect;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import android.view.View;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class MainActivity extends Activity {
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = (Button)findViewById(R.id.button);
    }
    public void buttonAction(View view)
    {
        ConnectivityManager cm = (ConnectivityManager)getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo[] = cm.getAllNetworkInfo();
        int i;
        for(i=0;i<networkInfo.length;++i)
        {
            if(networkInfo[i].getState()==NetworkInfo.State.CONNECTED)
            {
                Toast.makeText(getApplicationContext(),"Internet Connected",Toast.LENGTH_LONG).show();
                break;
            }
        }
        if (i==networkInfo.length)
        {
            Toast.makeText(getApplicationContext(),"Internet Not Connected",Toast.LENGTH_LONG).show();
        }
    }
}
