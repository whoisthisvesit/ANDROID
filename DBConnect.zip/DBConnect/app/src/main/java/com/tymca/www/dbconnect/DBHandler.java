package com.tymca.www.dbconnect;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHandler extends SQLiteOpenHelper
{
    private static final String DB_NAME = "vikramdb";
    private static final int DB_VERSION = 1;
    private static final String TABLE_NAME = "record";
    private static final String ID_COL = "id";
    private static final String NAME_COL="name";
   public DBHandler(Context context)
   {
       super(context,DB_NAME,null,DB_VERSION);
   }
   public void onCreate(SQLiteDatabase db)
   {
       String query = "Create TABLE "+TABLE_NAME+"("+ID_COL+"INTEGER PRIMARY KEY AUTOINCREMENT,"+NAME_COL+"TEXT)";
       db.execSQL(query);
   }
   public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion)
   {
       db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
       onCreate(db);
   }
   public void insertRecord(String name)
   {
       SQLiteDatabase db = this.getWritableDatabase();
       ContentValues values = new ContentValues();
       values.put(NAME_COL,name);
       db.insert(TABLE_NAME,null,values);
       db.close();
   }
   public String getRecords()
   {
       String query = "SELECT * FROM "+TABLE_NAME;
       String results="";
       SQLiteDatabase db = this.getReadableDatabase();
       Cursor cursor = db.rawQuery(query,null);
       cursor.moveToFirst();
       while (cursor.isAfterLast()==false)
       {
           results+=cursor.getString(0)+""+cursor.getString(1)+"\n";
           cursor.moveToNext();
       }
       db.close();
       return results;

   }
   public void updateRecord(String id,String name)
   {
       SQLiteDatabase db = this.getWritableDatabase();
       ContentValues values = new ContentValues();
       values.put(NAME_COL,name);
       db.update(TABLE_NAME,values,"id=?",new String[]{id});
       db.close();
   }
   public void deleteRecord(String id)
   {
       SQLiteDatabase db = this.getWritableDatabase();
       db.delete(TABLE_NAME,"id=?",new String[]{id});
       db.close();
   }

}
