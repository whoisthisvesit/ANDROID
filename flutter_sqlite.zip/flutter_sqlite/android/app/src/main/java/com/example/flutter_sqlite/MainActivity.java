package com.example.flutter_sqlite;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
