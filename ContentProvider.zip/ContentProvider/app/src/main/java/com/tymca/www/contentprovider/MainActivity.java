package com.tymca.www.contentprovider;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteCursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.annotation.Nullable;

public class MainActivity extends ContentProvider {

    private CouponSQLiteOpenHelper sqLiteOpenHelper;

    private static final String COUPONS_DBNAME = "zoftino";

    private static final String COUPON_TABLE = "coupon";

    private SQLiteDatabase cpnDB;

    private static final String SQL_CREATE_COUPON = "CREATE TABLE " +
            COUPON_TABLE +
            "(" +
            "_id INTEGER PRIMARY KEY, " +
            "STORE TEXT, " +
            "COUPON TEXT, " +
            "EXPIRES TEXT)";

    private static final UriMatcher uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
    static {
        uriMatcher.addURI("com.zoftino.coupon.provider", COUPON_TABLE, 1);
    }
    @Override
    public boolean onCreate() {
        //this way db create or open is delayed till getWritableDatabase() is called frist time
        sqLiteOpenHelper = new CouponSQLiteOpenHelper( getContext(), COUPONS_DBNAME, SQL_CREATE_COUPON );
        return true;
    }

    @Nullable
    @Override
    public Cursor query(Uri uri,String[] projection,String selection,String[] selectionArgs,
                        String sortOrder) {

        String tableNme = "";
        switch(uriMatcher.match(uri)){
            case 1 :
                tableNme = COUPON_TABLE;
                break;
            default:
                return null;
        }

        cpnDB = sqLiteOpenHelper.getWritableDatabase();

        Cursor cursor = (SQLiteCursor)cpnDB.query(tableNme, projection, selection, selectionArgs,
                null, null, sortOrder);
        return cursor;
    }

    @Nullable
    @Override
    public String getType(Uri uri) {
        return null;
    }

    @Nullable
    @Override
    public Uri insert(Uri uri, ContentValues contentValues) {

        String tableNme = "";
        switch(uriMatcher.match(uri)){
            case 1 :
                tableNme = COUPON_TABLE;
                break;
            default:
                return null;
        }

        cpnDB = sqLiteOpenHelper.getWritableDatabase();
        long rowid = cpnDB.insert(tableNme, null, contentValues);
        return getContentUriRow(rowid);
    }

    @Override
    public int delete(Uri uri, String where, String[] selectionArgs) {
        String tableNme = "";
        switch(uriMatcher.match(uri)){
            case 1 :
                tableNme = COUPON_TABLE;
                break;
            default:
                return 0;
        }

        cpnDB = sqLiteOpenHelper.getWritableDatabase();

        return cpnDB.delete(tableNme, where, selectionArgs);
    }

    @Override
    public int update(Uri uri, ContentValues contentValues, String where, String[] selectionArgs) {
        String tableNme = "";
        switch(uriMatcher.match(uri)){
            case 1 :
                tableNme = COUPON_TABLE;
                break;
            default:
                return 0;
        }
        cpnDB = sqLiteOpenHelper.getWritableDatabase();
        return cpnDB.update(tableNme,contentValues,where,selectionArgs );
    }
    private Uri getContentUriRow(long rowid){
        return Uri.fromParts("com.zoftino.coupon.provider", COUPON_TABLE, Long.toString(rowid));
    }
}
