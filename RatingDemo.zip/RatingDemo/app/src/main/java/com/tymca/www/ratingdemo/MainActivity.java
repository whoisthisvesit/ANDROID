package com.tymca.www.ratingdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RatingBar;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    RatingBar ratingBar;
    TextView textView,textView1;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ratingBar = (RatingBar)findViewById(R.id.ratingBar);
        textView =(TextView)findViewById(R.id.textView);
        button = (Button)findViewById(R.id.submitButton);
    }
    public void onSubmit(View view)
    {
        float ratingValue = ratingBar.getRating();
        if(ratingValue<2)
        {
            textView.setText("Rating"+ratingValue+"\n is worst");
        }
        else if(ratingValue<=3 && ratingValue>=2)
        {
            textView.setText("Rating"+ratingValue+" we will try better");
        }
        else if(ratingValue>3 && ratingValue<=4)
        {
            textView.setText("Rating"+ratingValue+"\n It is good");
        }
        else if(ratingValue>4)
        {
            textView.setText("Rating"+ratingValue+"\n Excellent");
        }
    }
}
