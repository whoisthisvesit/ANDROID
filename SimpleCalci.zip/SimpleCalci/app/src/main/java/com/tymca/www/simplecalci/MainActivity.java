package com.tymca.www.simplecalci;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button btnAdd,btnSub,btnMul,btnDiv;
    private TextView tvresult;
    private EditText etfirst,etsecond;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }
    private void init() {
        btnAdd = (Button) findViewById(R.id.btnAdd);
        btnSub = (Button) findViewById(R.id.btnSub);
        btnMul = (Button) findViewById(R.id.btnMul);
        btnDiv = (Button) findViewById(R.id.btnDiv);
        etfirst = (EditText) findViewById(R.id.etfirst);
        etsecond = (EditText) findViewById(R.id.etsecond);
        tvresult = (TextView) findViewById(R.id.tvresult);
        btnAdd.setOnClickListener(this);
        btnSub.setOnClickListener(this);
        btnMul.setOnClickListener(this);
        btnDiv.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        String num1 = etfirst.getText().toString();
        String num2 = etsecond.getText().toString();
        switch (view.getId())
        {
            case R.id.btnAdd:
                int add = Integer.parseInt(num1)+Integer.parseInt(num2);
                tvresult.setText(String.valueOf(add));
                break;
            case R.id.btnSub:
                int sub = Integer.parseInt(num1)-Integer.parseInt(num2);
                tvresult.setText(String.valueOf(sub));
                break;
            case R.id.btnMul:
                int mul = Integer.parseInt(num1)*Integer.parseInt(num2);
                tvresult.setText(String.valueOf(mul));
                break;
            case R.id.btnDiv:
                int div = Integer.parseInt(num1)/Integer.parseInt(num2);
                tvresult.setText(String.valueOf(div));
                break;
    }
}
}
