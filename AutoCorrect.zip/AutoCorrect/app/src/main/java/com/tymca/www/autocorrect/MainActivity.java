package com.tymca.www.autocorrect;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    AutoCompleteTextView acTextView;
    TextView textView;
    String [] inputs = {"India","Indonesia","Isreal","America","Austrilia","Canada","China","Denmark","France"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        acTextView = (AutoCompleteTextView)findViewById(R.id.acTextView);
        textView = (TextView)findViewById(R.id.textView);
        textView.setText("Text Inputs:\n India,Indonesia,Isreal,America,Austrilia,Canada,China,Denmark,France");
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,inputs);
        acTextView.setAdapter(adapter);

    }
}
