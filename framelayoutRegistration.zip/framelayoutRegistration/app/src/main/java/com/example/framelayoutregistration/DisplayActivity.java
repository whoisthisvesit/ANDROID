package com.example.framelayoutregistration;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class DisplayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        TextView nameDisplay, rollDisplay, courseDisplay, phoneDisplay;


        nameDisplay = findViewById(R.id.nameDisplay);
        rollDisplay = findViewById(R.id.rollDisplay);
        courseDisplay = findViewById(R.id.courseDisplay);
        phoneDisplay = findViewById(R.id.phoneDisplay);


        Intent iin= getIntent();
        Bundle b = iin.getExtras();

        if(b!=null)
        {
            String nameTextStr =(String) b.get("nameText");
            String rollTextStr =(String) b.get("rollText");
            String courseTextStr =(String) b.get("courseText");
            String phoneTextStr =(String) b.get("phoneText");


            nameDisplay.setText(nameTextStr);
            rollDisplay.setText(rollTextStr);
            courseDisplay.setText(courseTextStr);
            phoneDisplay.setText(phoneTextStr);


        }
}
}