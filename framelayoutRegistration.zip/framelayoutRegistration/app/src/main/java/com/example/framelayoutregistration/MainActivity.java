package com.example.framelayoutregistration;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView textView;
    EditText name, roll,course,phone;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // finding the UI elements

        textView = findViewById(R.id.txtvw1);
        name = findViewById(R.id.name);
        roll = findViewById(R.id.roll);
        course = findViewById(R.id.course);
        phone = findViewById(R.id.phone);
        btn= findViewById(R.id.submit);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nameText = name.getText().toString();
                String rollText = roll.getText().toString();
                String courseText = course.getText().toString();
                String phoneText = phone.getText().toString();


                Intent ii=new Intent(MainActivity.this, DisplayActivity.class);
                ii.putExtra("nameText", nameText);
                ii.putExtra("rollText", rollText);
                ii.putExtra("courseText", courseText);
                ii.putExtra("phoneText", phoneText);
                startActivity(ii);


            }
        });
    }
}
