package com.example.converter;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class LengthActivity extends AppCompatActivity {
    Button length;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_length);
        final EditText etlen;
        final TextView etmsg;
        length=findViewById(R.id.btn6);
        etlen=findViewById(R.id.et2);
        etmsg=findViewById(R.id.txt2);
        length.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double convert= Double.parseDouble(etlen.getText().toString());
                etmsg.setText(String.valueOf(convert*100));               //Just put the formula here accordingly!!!
                etmsg.setTextColor(Color.RED);
            }
        });
}}