package com.example.converter;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
public class CurrencyActivity extends AppCompatActivity {
Button curr;
TextView msg;
EditText value;
Double convert;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_currency);
        value=findViewById(R.id.et3);
        curr=findViewById(R.id.btn7);
        msg=findViewById(R.id.txt3);
        curr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                convert= Double.parseDouble(value.getText().toString());
                msg.setText(String.valueOf(convert*81.67));               //Just put the formula here accordingly!!!
                msg.setTextColor(Color.RED);
            }
        });
    }
}