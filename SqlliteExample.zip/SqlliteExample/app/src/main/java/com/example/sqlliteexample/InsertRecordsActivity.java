package com.example.sqlliteexample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class InsertRecordsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_records);

        final EditText ETprofName, ETprofRole, ETexperience, ETexpertise;
        final Button submit, back;
        final TextView status;

        SQLiteDatabaseHandler db= new SQLiteDatabaseHandler(this);

        ETprofName = findViewById(R.id.name);
        ETprofRole = findViewById(R.id.role);
        ETexperience = findViewById(R.id.exp);
        ETexpertise = findViewById(R.id.expertise);

        submit = findViewById(R.id.button);
        back = findViewById(R.id.back);

        status = findViewById(R.id.textView3);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(i);
                finish();
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String name = ETprofName.getText().toString();
                final String role = ETprofRole.getText().toString();
                final Integer exp = Integer.parseInt(ETexperience.getText().toString());
                final String expertise = ETexpertise.getText().toString();

                if (name.isEmpty())
                {
                    ETprofName.setError("This field can't be empty!");
                }

                if (role.isEmpty())
                {
                    ETprofRole.setError("This field can't be empty!");
                }

                if (exp==null)
                {
                    ETexperience.setError("This field can't be empty!");
                }

                if (expertise.isEmpty())
                {
                    ETexpertise.setError("This field can't be empty!");
                }

                if(!name.isEmpty() && !role.isEmpty() && exp!=null && !expertise.isEmpty() ) {
                    McaDept mcaDept = new McaDept(name, role, exp, expertise);
                    db.addProfInDB(mcaDept);
                        status.setText("Record added sucessfully!");
                    }
            }
        });
    }
}