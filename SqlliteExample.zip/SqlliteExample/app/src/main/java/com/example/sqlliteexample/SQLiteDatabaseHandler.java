package com.example.sqlliteexample;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class SQLiteDatabaseHandler extends SQLiteOpenHelper {
    // All Static variables
    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "mcaDeptData";

    // TABLE_PROF table name
    private static final String TABLE_PROF= "profData";

    // TABLE_PROF Table Columns names
    private static final String KEY_ID = "id";
    private static final String PROF_NAME = "profName";
    private static final String PROF_JOB_ROLE = "profRole";
    private static final String EXPERIENCE = "experience";
    private static final String EXPERTISE = "expertise";

    public SQLiteDatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_PROF + "("
                + KEY_ID + " INTEGER PRIMARY KEY," + PROF_NAME + " TEXT," + PROF_JOB_ROLE + " TEXT,"
                + EXPERIENCE + " INT," + EXPERTISE + " TEXT" + ")";
        sqLiteDatabase.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        // Drop older table if existed
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_PROF);
        // Create tables again
        onCreate(sqLiteDatabase);
    }

    /**
     * All CRUD(Create, Read, Update, Delete) Operations
     */

    // Adding new entry
    void addProfInDB(McaDept mcaDept) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(PROF_NAME, mcaDept.getProfName());
        values.put(PROF_JOB_ROLE, mcaDept.getProfJobRole());
        values.put(EXPERIENCE, mcaDept.getExperience());
        values.put(EXPERTISE, mcaDept.getExpertise());

        // Inserting Row
        db.insert(TABLE_PROF, null, values);
        db.close(); // Closing database connection
    }

    // Getting single record
    McaDept getSingleRecord(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_PROF, new String[] { KEY_ID, PROF_NAME, PROF_JOB_ROLE, EXPERIENCE, EXPERTISE}, KEY_ID + "=?",
                new String[] { String.valueOf(id) }, null, null, null, null);

        if (cursor != null) {
            cursor.moveToFirst();
        }
        McaDept mcaDept = new McaDept(cursor.getInt(0), cursor.getString(1), cursor.getString(2), cursor.getInt(3), cursor.getString(4));
        return mcaDept;
    }

    // Getting All Records
    public List getAllRecords() {
        List recordList = new ArrayList();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_PROF;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                McaDept mcaDept = new McaDept();
                mcaDept.setId(cursor.getInt(0));
                mcaDept.setProfName(cursor.getString(1));
                mcaDept.setProfJobRole(cursor.getString(2));
                mcaDept.setExperience(cursor.getInt(3));
                mcaDept.setExpertise(cursor.getString(4));
                // Adding records to list
                recordList.add(mcaDept);
            } while (cursor.moveToNext());
        }

        // return records list
        return recordList;
    }

    // Updating single record
    public int updateRecord(McaDept mcaDept) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(PROF_NAME, mcaDept.getProfName());
        values.put(PROF_JOB_ROLE, mcaDept.getProfJobRole());
        values.put(EXPERIENCE, mcaDept.getExperience());
        values.put(EXPERTISE, mcaDept.getExpertise());

        // updating row
        return db.update(TABLE_PROF, values, KEY_ID + " = ?", new String[] { String.valueOf(mcaDept.getId()) });
    }

    // Deleting single record
    public void deleteRecord(McaDept mcaDept) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_PROF, KEY_ID + " = ?", new String[] { String.valueOf(mcaDept.getId()) });
        db.close();
    }

    // Deleting all records
    public void deleteAllRecords() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_PROF,null,null);
        db.close();
    }

    // Getting Records Count
    public int getRecordsCount() {
        String countQuery = "SELECT  * FROM " + TABLE_PROF;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        cursor.close();
        // return count
        return cursor.getCount();
    }

}
