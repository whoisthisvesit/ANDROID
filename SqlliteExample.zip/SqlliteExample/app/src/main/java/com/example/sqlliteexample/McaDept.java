package com.example.sqlliteexample;

public class McaDept {
    int id;
    String profName;
    String profJobRole;
    int experience;
    String expertise;

    public McaDept() {
        super();
    }

    public McaDept(int id, String profName, String profJobRole, int experience, String expertise) {
        super();
        this.id = id;
        this.profName = profName;
        this.profJobRole = profJobRole;
        this.experience = experience;
        this.expertise = expertise;
    }

    public McaDept(String profName, String profJobRole, int experience, String expertise) {
        super();
        this.profName = profName;
        this.profJobRole = profJobRole;
        this.experience = experience;
        this.expertise = expertise;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getProfName() {
        return profName;
    }

    public void setProfName(String profName) {
        this.profName = profName;
    }

    public String getProfJobRole() {
        return profJobRole;
    }

    public void setProfJobRole(String profJobRole) {
        this.profJobRole = profJobRole;
    }

    public int getExperience() {
        return experience;
    }

    public void setExperience(int experience) {
        this.experience = experience;
    }

    public String getExpertise() {
        return expertise;
    }

    public void setExpertise(String expertise) {
        this.expertise = expertise;
    }
}
