package com.tymca.www.internalmemory;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;


public class MainActivity extends AppCompatActivity {
    Button read, write;
    EditText editText;
    TextView displayName;
    String fileName = "myText";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        read = (Button) findViewById(R.id.btnRead);
        write = (Button) findViewById(R.id.btnWrite);
        editText = (EditText) findViewById(R.id.editText);
        displayName = (TextView) findViewById(R.id.textView);

    }

    public void writeBtnClick(View view) {
        String name = editText.getText().toString();
        if (name.equals(String.valueOf(""))) {
            editText.setError("Please enter your name");
        } else {
            try {
                FileOutputStream fileout = openFileOutput(fileName, MODE_APPEND);
                OutputStreamWriter outputWriter = new OutputStreamWriter(fileout);
                outputWriter.write(name);
                outputWriter.close();
                editText.setText(" ");
                Toast.makeText(getApplicationContext(), "File saved Successfully", Toast.LENGTH_LONG).show();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }

    public void readBtnClick(View view) {
        try {
            FileInputStream fileIn = openFileInput(fileName);
            InputStreamReader inputRead = new InputStreamReader(fileIn);
            BufferedReader bufferedReader = new BufferedReader(inputRead);
            StringBuilder stringBuilder = new StringBuilder();
            String line = null;
            while ((line = bufferedReader.readLine()) != null) {
                stringBuilder.append(line);
            }
            fileIn.close();
            inputRead.close();
            Toast.makeText(getBaseContext(), "File read successfuly", Toast.LENGTH_LONG).show();
            displayName.setText("Name" + stringBuilder.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
