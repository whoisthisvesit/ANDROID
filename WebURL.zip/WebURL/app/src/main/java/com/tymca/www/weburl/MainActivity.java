package com.tymca.www.weburl;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    Button openBtn;
    EditText url;
    WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        openBtn = (Button)findViewById(R.id.openBtn);
        url = (EditText)findViewById(R.id.url);
        webView = (WebView)findViewById(R.id.webView);
        webView.getSettings().setJavaScriptEnabled(true);
       openBtn.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               webView.setWebViewClient(new CustomWebClient());
               webView.loadUrl(url.getText().toString());
           }
       });
    }
    public class CustomWebClient extends WebViewClient
    {
        public boolean shouldOverrideUrlLoading(WebView view,String url)
        {
            view.loadUrl(url);
            return true;

        }
    }
}
