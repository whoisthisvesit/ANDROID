package com.tymca.www.inetrestcal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Button;
import android.widget.EditText;
import android.view.View;


public class MainActivity extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final   EditText amt = (EditText)findViewById(R.id.bill_amt);
        final EditText per = (EditText)findViewById(R.id.bill_per);
       final   TextView result = (TextView)findViewById(R.id.res);
        Button  cal = (Button)findViewById(R.id.button1);
         cal.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 double amount = Double.parseDouble(amt.toString());
                 double percentage = Double.parseDouble(per.toString());
                 double res1 = amount*percentage;
                 result.setText("Result"+Double.toString(res1));
             }
         });
    }
}
