package com.tymca.www.radiog;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import android.widget.RelativeLayout;


public class MainActivity extends AppCompatActivity {
    RadioGroup radioGroup;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        radioGroup = (RadioGroup)findViewById(R.id.radioGroup);
        relativeLayout = (RelativeLayout)findViewById(R.id.relativeLayout);
       radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
           @Override
           public void onCheckedChanged(RadioGroup radioGroup, int i) {
               switch (i)
               {
                   case R.id.radiobutton1:
                       relativeLayout.setBackgroundColor(Color.parseColor("#ff0000"));
                       break;
                   case R.id.radiobutton2:
                       relativeLayout.setBackgroundColor(Color.parseColor("#00ff00"));
                       break;
                   case R.id.radiobutton3:
                       relativeLayout.setBackgroundColor(Color.parseColor("#0000ff"));
                   case R.id.radiobutton4:
                       relativeLayout.setBackgroundColor(Color.parseColor("#00ffff"));
               }
           }
       });

    }
}
