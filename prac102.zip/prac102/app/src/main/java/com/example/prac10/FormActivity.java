package com.example.prac10;

import androidx.appcompat.app.AppCompatActivity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
public class FormActivity extends AppCompatActivity {
    EditText t1,t2,t3;
    Button SignUpBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);
        t1=(EditText)findViewById(R.id.t1);
        t2=(EditText)findViewById(R.id.t2);
        t3=(EditText)findViewById(R.id.t3);
        SignUpBtn=(Button)findViewById(R.id.SignUpBtn);
        SignUpBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                processSignUp();
            }
        });
    }
    void processSignUp(){
        String name = t1.getText().toString();
        String email = t2.getText().toString();
        String password = t3.getText().toString();
        Call<ResponseModel> call = Controller.getInstance().getapi().verifyuser(name,email,password);
        call.enqueue(new Callback<ResponseModel>() {
            @Override
            public void onResponse(Call<ResponseModel> call,
                                   Response<ResponseModel> response) {
                ResponseModel obj=response.body();
                String output=obj.getMessage();
                if(output.equals("exist")) {
                    t1.setText("");
                    t2.setText("");
                    t3.setText("");
                    Toast.makeText(getApplicationContext(),"User Already Exist", Toast.LENGTH_LONG).show();
                }
                if(output.equals("success")) {
                    Toast.makeText(getApplicationContext(),"User Registered Successfully", Toast.LENGTH_LONG).show();
                }
                if(output.equals("failed")) {
                    Toast.makeText(getApplicationContext(),"Something went wrong", Toast.LENGTH_LONG).show();
                }
                if(output.equals("failed")) {
                    Toast.makeText(getApplicationContext(),"Connection failure", Toast.LENGTH_LONG).show();
                }
            }
            @Override
            public void onFailure(Call<ResponseModel> call, Throwable t) {
                Toast.makeText(getApplicationContext(),t +" "+call, Toast.LENGTH_LONG).show();
            }
        });}}
