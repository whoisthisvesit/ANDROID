package com.example.prac10;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
public interface Apiset {
    @FormUrlEncoded
    @POST("/PHP/Signup.php")
    Call<ResponseModel> verifyuser(
            @Field("name") String name,
            @Field("email") String email,
            @Field("password") String password
    );
}
