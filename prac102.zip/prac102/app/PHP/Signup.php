<?php
$conn = mysqli_connect("localhost","root","","android");
$name=trim($_POST['name']);
$email=trim($_POST['email']);
$pass=trim($_POST['password']);
if($conn)
{
$qry = "select * from form where email='$email'";
$result = mysqli_query($conn,$qry);
if(mysqli_num_rows($result)>0)
{
$response['message']="exist";
echo json_encode($response);
}
else
{
$qry = "insert into form(name,email,password)values('$name','$email','$pass')";
if(mysqli_query($conn,$qry))
{
$response['message']="success";
}
else{
$response['message']="failed";
}
echo json_encode($response);
}
}
else{

$response['message']="failed";
echo json_encode($response);

}
?>
