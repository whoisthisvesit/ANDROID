package com.tymca.www.lifecycledemo;

import static org.junit.Assert.*;

public class MainActivityTest {

}