package com.tymca.www.lifecycledemo;

import android.app.Activity;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.annotation.SuppressLint;
        import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        notify("onCreate");
    }
    protected void onPause()
    {
        super.onPause();
        notify("onPause");
    }
    protected void onResume()
    {
        super.onResume();
        notify("onResume");
    }
    protected void onStop()
    {
        super.onStop();
        notify("onStop");
    }
    protected void onDestroy()
    {
        super.onDestroy();
        notify("onDestroy");
    }
     protected void onRestoreInstanceState(Bundle savedInstanceState)
     {
         super.onRestoreInstanceState(savedInstanceState);
         notify("onRestoreInstanceSate");
     }
     protected void onSaveInstanceState(Bundle outState)
     {
         super.onSaveInstanceState(outState);
         notify("onSaveInstanceState");
     }
     private void notify(String methodName)
     {
         String name = this.getClass().getName();
         String [] strings = name.split("\\.");
         Toast.makeText(getApplicationContext(),methodName+" "+strings[strings.length - 1],Toast.LENGTH_LONG).show();
     }
}
