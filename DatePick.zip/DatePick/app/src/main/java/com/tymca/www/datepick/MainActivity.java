package com.tymca.www.datepick;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import java.util.Calendar;
import android.widget.TextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.view.View;
import android.app.Dialog;
import android.app.DatePickerDialog;

public class MainActivity extends AppCompatActivity {
     Button setDateBtn;
     TextView selectedDateTxt;
     int day,month,year;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setDateBtn = (Button)findViewById(R.id.setDateBtn);
        selectedDateTxt = (TextView)findViewById(R.id.selectedDateTxt);
        Calendar c = Calendar.getInstance();
        day = c.get(Calendar.DAY_OF_MONTH);
        month = c.get(Calendar.MONTH);
        year = c.get(Calendar.YEAR);
        displayDate(day,month,year);
        setDateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog(111);
            }
        });
    }
    void displayDate(int day,int month,int year)
    {
        selectedDateTxt.setText("Date "+day+"/"+month+"/"+year);
    }
    protected Dialog onCreateDialog(int id)
    {
        if(id==111)
        {
            return new DatePickerDialog(this,dateLPickerListener,year,month,day);

        }
        return null;
    }


private DatePickerDialog.OnDateSetListener dateLPickerListener = new DatePickerDialog.OnDateSetListener() {
    @Override
    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
        displayDate(day,month+1,year);
    }
};
}
