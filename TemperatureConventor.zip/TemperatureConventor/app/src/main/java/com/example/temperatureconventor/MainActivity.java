package com.example.temperatureconventor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
RadioGroup rg1;
RadioButton rb;
Button b1;
EditText ed1;
TextView tv1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rg1 = findViewById(R.id.radioGroup);

        b1 = findViewById(R.id.button);
        ed1 = findViewById(R.id.ed1);
        tv1 = findViewById(R.id.textView);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int selectedid = rg1.getCheckedRadioButtonId();

                rb = findViewById(selectedid);

                if(rb.getText().toString().equals("TO CELSIUS"))
                {
                    double a=Double.parseDouble(String.valueOf(ed1.getText()));
                    Double b=a-32;
                    Double c=b*5/9;
                    String r=String.valueOf(c);
                    tv1.setText("TEMPERATURE IN CELSIUS: "+ r + " C" );
                }

                if(rb.getText().toString().equals("TO FAHRENHIT"))
                {
                    double a=Double.parseDouble(String.valueOf(ed1.getText()));
                    Double b=a*9/5+32;
                    String r=String.valueOf(b);

                    tv1.setText("TEMPERATURE IN FAHRENHIT: "+ r + " F" );
                }


            }
        });

    }
}